package de.uni_hamburg.informatik.swt.se2.kino.fachwerte;

/**
 * Die Altersfreigaben der FSK.
 * 
 * @author SE2-Team
 * @version April 2010.
 */
public enum FSK
{
    FSK0, FSK6, FSK12, FSK16, FSK18;
}

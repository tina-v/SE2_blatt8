package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.platzverkauf;

public class BarzahlungsWerkzeug extends PlatzVerkaufsWerkzeug
{
	private BarzahlungsWerkzeugUI _ui;
	
	public BarzahlungsWerkzeug()
	{
		_ui = new BarzahlungsWerkzeugUI();
	}

    
}

package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.platzverkauf;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;

/**
 * Die UI des {@link PlatzVerkaufsWerkzeug}.
 * 
 * @author Ms X
 * @version 16.06
 */
public class BarzahlungsWerkzeugUI {
	
	    // Die Widgets, aus denen das UI sich zusammensetzt
		private GridLayout _hauptPanel;
	    private JLabel _text1;
	    private JLabel _text2;
	    private JLabel _text3;
	    private GridLayout _BarzahlungsFenster;
	    private JLabel _restBetragLabel;
	    private JLabel _eingabeFeld;
	    private JLabel _preisLabel;
	    private JButton _verkaufenButton;
	    private JButton _abbrechenButton;
	    
	   
	    /**
	     * Initialisiert die UI.
	     */
	    public BarzahlungsWerkzeugUI()
	    {
	    	_hauptPanel = erstellePanel();	
	    }

	    /**
	     * Erzeugt das Panel, in dem Gesamtbetrag, Restbetrag, Eingabefeld dargestellt
	     * wird.
	     */
	    private GridLayout erstellePanel()
	    {	    	 
	        _BarzahlungsFenster = new GridLayout(4,2);
	        _BarzahlungsFenster.addLayoutComponent("Gesamtbetrag",_text1);
	        _BarzahlungsFenster.addLayoutComponent(getPreis(), _preisLabel);
	        _BarzahlungsFenster.addLayoutComponent("Bezahlterbetrag", _text2);
	        _BarzahlungsFenster.addLayoutComponent("Eingabefeld", _eingabeFeld);
	        _BarzahlungsFenster.addLayoutComponent("Restbetrag", _text3);
	        _BarzahlungsFenster.addLayoutComponent(getRestbetrag(), _restBetragLabel);
	        _BarzahlungsFenster.addLayoutComponent("Zahlen", _verkaufenButton);
	        _BarzahlungsFenster.addLayoutComponent("Abbrechen", _abbrechenButton);
	        
	        return _BarzahlungsFenster;
	    }

	    public String getPreis()
	    {
	    	return "0";
	    }
	    
	    public String getRestbetrag()
	    {
	    	return "0";
	    }
	    
	    public JButton getVerkaufenButton()
	    {
	    	return _verkaufenButton;
	    }
	    public GridLayout getUIPanel()
	    {
	    	return _hauptPanel;
	    }
	}

